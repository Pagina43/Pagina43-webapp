import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';

export const supabase = createClient(
  'https://dhckkseygocebezqthkk.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRoY2trc2V5Z29jZWJlenF0aGtrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM1MjQ2OTYsImV4cCI6MjA2OTEwMDY5Nn0.0sn6G1GxexfLobXnlRhRkK8cPD92Kmok1MZSi6W6ubE'
);
