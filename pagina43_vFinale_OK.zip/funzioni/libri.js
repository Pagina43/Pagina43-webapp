import { supabase } from '../supabaseClient.js';

export async function caricaLibri() {
  const main = document.getElementById('main-content');
  main.innerHTML = '<h2>Libri in adozione</h2><input type="text" id="filtro-libri" placeholder="Cerca per titolo, disciplina, editore..." style="width: 100%; margin-bottom: 10px; padding: 6px;"><div id="lista-libri"></div>';

  const { data, error } = await supabase.from('adozioni_libri').select('*');
  if (error) {
    document.getElementById('lista-libri').innerHTML = '<p>Errore nel caricamento dei libri</p>';
    return;
  }

  const lista = document.getElementById('lista-libri');
  data.forEach((libro) => {
    const div = document.createElement('div');
    div.className = 'scheda-libro';
    div.innerHTML = `
      <strong>${libro.disciplina}</strong> – ISBN: ${libro.isbn}<br>
      ${libro.titolo} – Volume ${libro.volume} – ${libro.editore}
    `;
    lista.appendChild(div);
  });

  document.getElementById('filtro-libri').addEventListener('input', function () {
    const filtro = this.value.toLowerCase();
    const schede = document.querySelectorAll('.scheda-libro');
    schede.forEach((scheda) => {
      const testo = scheda.textContent.toLowerCase();
      scheda.style.display = testo.includes(filtro) ? 'block' : 'none';
    });
  });
}
