import { supabase } from '../supabaseClient.js';

export async function caricaIstituti() {
  const main = document.getElementById('main-content');
  main.innerHTML = '<h2>Istituti</h2><input type="text" id="filtro-istituti" placeholder="Cerca istituto..." style="width: 100%; margin-bottom: 10px; padding: 6px;"><div id="lista-istituti"></div>';

  const { data, error } = await supabase.from('istituti').select('*');
  if (error) {
    document.getElementById('lista-istituti').innerHTML = '<p>Errore nel caricamento degli istituti</p>';
    return;
  }

  const lista = document.getElementById('lista-istituti');
  data.forEach((scuola) => {
    const div = document.createElement('div');
    div.className = 'scheda-istituto';
    div.innerHTML = `
      <strong>${scuola.nome}</strong> – ${scuola.comune} (${scuola.provincia})<br>
      <small>Codice: ${scuola.codice_scuola}</small><br><br>
      <button onclick="alert('Scheda scuola: ${scuola.nome}')">📂 Apri scheda</button>
      <button onclick="caricaLibriDellaScuola('${scuola.codice_scuola}')">📘 Libri in adozione</button>
      <button onclick="alert('Funzione docenti non ancora attiva')">👨‍🏫 Docenti</button>
    `;
    lista.appendChild(div);
  });

  document.getElementById('filtro-istituti').addEventListener('input', function () {
    const filtro = this.value.toLowerCase();
    const schede = document.querySelectorAll('.scheda-istituto');
    schede.forEach((scheda) => {
      const testo = scheda.textContent.toLowerCase();
      scheda.style.display = testo.includes(filtro) ? 'block' : 'none';
    });
  });
}
