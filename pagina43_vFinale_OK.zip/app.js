import { caricaIstituti } from './funzioni/istituti.js';
import { caricaLibri } from './funzioni/libri.js';

export function caricaSezione(sezione) {
  const main = document.getElementById('main-content');
  main.innerHTML = '';

  switch (sezione) {
    case 'istituti':
      caricaIstituti();
      break;
    case 'libri':
      caricaLibri();
      break;
    default:
      main.innerHTML = '<p>Sezione non trovata</p>';
  }
}

window.caricaSezione = caricaSezione;
